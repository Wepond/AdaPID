import os
# %matplotlib notebook
import matplotlib.pyplot as plt
import torch
import numpy as np

#LABELS = ['AdaL','Adam', 'NosAdam', 'AmsGrad','AdaBound','AdaGrad','AdaMod']
LABELS = ['AdaPID','PID', 'SGD', 'Adam','NosAdam', 'AmsGrad','AdaBound','AdaGrad']
metrics = ['accuracy', 'loss']
models = ['DenseNet']


def get_folder_path(use_pretrained=True):
    path = 'curve'
    if use_pretrained:
        path = os.path.join(path, 'pretrained')
    return path


def get_curve_data(use_pretrained=True, model='DenseNet'):
    folder_path = get_folder_path(use_pretrained)
    filenames = [name for name in os.listdir(folder_path) if name.startswith(model.lower())]
    paths = [os.path.join(folder_path, name) for name in filenames]
    keys = [name.split('-')[1] for name in filenames]
    print(paths, keys)
    return {key: torch.load(fp) for key, fp in zip(keys, paths)}


def plot(use_pretrained=True, model='DenseNet', optimizers=None, curve_type='train', metric='accuracy'):
    # assert model in ['ResNet', 'DenseNet'], 'Invalid model name: {}'.format(model)
    assert curve_type in ['train', 'test'], 'Invalid curve type: {}'.format(curve_type)
    assert metric in ['accuracy', 'loss'], 'Invalid curve type: {}'.format(metric)
    assert all(_ in LABELS for _ in optimizers), 'Invalid optimizer'

    curve_data = get_curve_data(use_pretrained, model=model)
    plt.figure()
    plt.xlabel('Epoch')
    plt.ylabel('{} {} %'.format(curve_type.capitalize(), metric.capitalize()))
    if metric == 'accuracy':
    	plt.ylim(80, 101 if curve_type == 'train' else 96)

    for optim in optimizers:
        linestyle = '--' if 'Bound' in optim else '-'
        curve = np.array(curve_data[optim.lower()]['{}_{}'.format(curve_type, metric)])
        if metric == 'loss':
            curve = np.log(curve)
        plt.plot(curve, label=optim, ls=linestyle)
    plt.legend()
    plt.savefig('figure/{}-{}-{}.png'.format(model, curve_type, metric))


for metric in metrics:
    for model in models:
        plot(use_pretrained=False, model=model, optimizers=LABELS, curve_type='train', metric=metric)
        plot(use_pretrained=False, model=model, optimizers=LABELS, curve_type='test', metric=metric)
