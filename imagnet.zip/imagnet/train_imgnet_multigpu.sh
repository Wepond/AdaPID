CUDA_VISIBLE_DEVICES=1,5,7 \
python main_imagenet.py \
-a regnet --arch_config regnet_y_200MF \
--print_freq 100 \
--optim adapid \
--dist-url 'tcp://127.0.0.1:10077' \
--dist-backend 'nccl' \
--multiprocessing-distributed --world-size 1 --rank 0 