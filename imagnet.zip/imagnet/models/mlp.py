import torch
import torch.nn as nn
import torch.nn.functional as F


class MLP(nn.Module):
    def __init__(self, in_features, num_class=10):
        super(MLP, self).__init__()
        self.fc1 = nn.Sequential(
            nn.Linear(in_features, 100),
            nn.ReLU(),
            nn.Linear(100, 100),
            nn.ReLU()
        )
        self.fc2 = nn.Linear(100, num_class)

    def forward(self, x):
        x = self.fc1(x)
        output = self.fc2(x)
        return output


def MLP10O(args):
    return MLP(784, 10)
