# ImageNet training code 说明

以文件夹中写好的 train_imgnet_multigpu.sh 为例说明：

CUDA_VISIBLE_DEVICES=0,1 \

python main_imagenet.py \

-a regnet --arch_config regnet_y_200MF \

--print_freq 100 \

--optim sgd \

--dist-url 'tcp://127.0.0.1:10077' \

--dist-backend 'nccl' \

--multiprocessing-distributed --world-size 1 --rank 0 

CUDA_VISIBLE_DEVICES=0,1 python3 main_imagenet.py -a resnet_imagenet --arch_config resnet18 --optim sgd --lr 0.1

CUDA_VISIBLE_DEVICES=0,1 python3 main_imagenet.py -a regnet --arch_config _config regnet_y_200MF --optim detaadam --lr 0.001
1. 第一行指定gpu，主文件为main_imagenet.py
2. -a 填写models文件夹里模型的文件名，--arch_config是该文件里具体某个模型。如-a regnet, --arch_config regnet_y_200MF, 再如 -a resnet_imagenet, --arch_config resnet18. 现支持的模型有：
   1. resnet（18，34，50，101，152）
   2. wide_resnet (50x2, 101x2)
   3.  resnext (50_32x4d, 101_32x4d, 101_32x8d等，具体见resnet_imagenet.py
   4. densenet_bc (也是多种config，在代码里写好了model)
   5. Mobilenet_v2
   6. Regnet (现只有一个200M FLOPs的轻量模型，如需增加更多配置，可自定义)
3. Print_freq是训练过程中打印中间acc等的频率。
4. --optim选优化器
5. 后面几行是多gpu并行所需的参数，同一台机器上跑多个程序时，端口号10077可换（任意空闲端口号），其他不用改。
