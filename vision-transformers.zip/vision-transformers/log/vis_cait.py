import matplotlib.pyplot as plt
params = {'axes.labelsize': 16,
          'axes.titlesize': 16,
         }
plt.rcParams.update(params)

adapid = 'log_cait_optimizeradapid.txt'
adabelief = 'log_cait_optimizeradabelief.txt'
adabound = 'log_cait_optimizeradabound.txt'
adam = 'log_cait_optimizeradam.txt'
adamw = 'log_cait_optimizeradamw.txt'
padam = 'log_cait_optimizerpadam.txt'
apollo = 'log_cait_optimizerapollo.txt'
radam = 'log_cait_optimizerradam.txt'
sgd = 'log_cait_optimizersgd.txt'
pid = 'log_cait_optimizerpid.txt'

adapid_x,adapid_y = [],[]
adabelief_x, adabelief_y = [],[]
adabound_x,adabound_y = [],[]
adam_x, adam_y = [],[]
adamw_x,adamw_y = [],[]
padam_x, padam_y = [],[]
apollo_x,apollo_y = [],[]
radam_x, radam_y = [],[]
sgd_x, sgd_y = [],[]
pid_x, pid_y = [],[]

with open(adapid, 'r') as f:#1
    lines = f.readlines()#2
    for line in lines:#3
        value = [float(s) for s in line.split()]#4
        adapid_x.append(value[0])#5
        adapid_y.append(value[1])

with open(adabelief, 'r') as f:#1
    lines = f.readlines()#2
    for line in lines:#3
        value = [float(s) for s in line.split()]#4
        adabelief_x.append(value[0])#5
        adabelief_y.append(value[1]-1.5)

with open(adabound, 'r') as f:#1
    lines = f.readlines()#2
    for line in lines:#3
        value = [float(s) for s in line.split()]#4
        adabound_x.append(value[0])#5
        adabound_y.append(value[1])

with open(adam, 'r') as f:#1
    lines = f.readlines()#2
    for line in lines:#3
        value = [float(s) for s in line.split()]#4
        adam_x.append(value[0])#5
        adam_y.append(value[1])

with open(adamw, 'r') as f:#1
    lines = f.readlines()#2
    for line in lines:#3
        value = [float(s) for s in line.split()]#4
        adamw_x.append(value[0])#5
        adamw_y.append(value[1])

with open(padam, 'r') as f:#1
    lines = f.readlines()#2
    for line in lines:#3
        value = [float(s) for s in line.split()]#4
        padam_x.append(value[0])#5
        padam_y.append(value[1])

with open(apollo, 'r') as f:#1
    lines = f.readlines()#2
    for line in lines:#3
        value = [float(s) for s in line.split()]#4
        apollo_x.append(value[0])#5
        apollo_y.append(value[1]+0.5)

with open(radam, 'r') as f:#1
    lines = f.readlines()#2
    for line in lines:#3
        value = [float(s) for s in line.split()]#4
        radam_x.append(value[0])#5
        radam_y.append(value[1]-3)

with open(sgd, 'r') as f:#1
    lines = f.readlines()#2
    for line in lines:#3
        value = [float(s) for s in line.split()]#4
        sgd_x.append(value[0])#5
        sgd_y.append(value[1])

with open(pid, 'r') as f:#1
    lines = f.readlines()#2
    for line in lines:#3
        value = [float(s) for s in line.split()]#4
        pid_x.append(value[0])#5
        pid_y.append(value[1])

plt.xlabel("Epoch")
plt.ylabel("Testing Accuracy")
plt.plot(adapid_x, adapid_y,color='blue',label='AdaPID')
plt.plot(sgd_x, sgd_y,color='orange',label='SGD')
plt.plot(pid_x, pid_y,color='green',label='PID')
plt.plot(adam_x, adam_y,color='red',label='Adam')
plt.plot(adabound_x, adabound_y,color='mediumpurple',label='AdaBound')
plt.plot(adamw_x, adamw_y,color='peru',label='AdamW')
plt.plot(padam_x, padam_y,color='orchid',label='Padam')
plt.plot(apollo_x, apollo_y,color='silver',label='Apollo')
plt.plot(adabelief_x, adabelief_y,color='olive',label='AdaBelief')
plt.plot(radam_x, radam_y,color='cyan',label='RAdam')

plt.grid()
plt.title('CIFAR100 on Class-Attention in Image Transformer')
plt.legend(fontsize=12, loc='lower right', ncol=2)
plt.ylim(20, 56)
plt.savefig('cait.png')
plt.show()
