import math
import torch
from torch.optim.optimizer import Optimizer


class ADAPID(Optimizer):
 
    def __init__(self, params, lr=1e-3, weight_decay=0):
        if not 0.0 <= lr:
            raise ValueError("Invalid learning rate: {}".format(lr))
       
        defaults = dict(lr=lr, weight_decay=weight_decay)
        super(ADAPID, self).__init__(params, defaults)

    def __setstate__(self, state):
        super(ADAPID, self).__setstate__(state)

    def step(self, closure=None):

        loss = None
        if closure is not None:
            loss = closure()

        for group in self.param_groups:
            for p in group['params']:
                if p.grad is None:
                    continue
                grad = p.grad.data
                if grad.is_sparse:
                    raise RuntimeError('Adam does not support sparse gradients, please consider SparseAdam instead')

                state = self.state[p]

                # State initialization
                if len(state) == 0:
                    state['step'] = 0
                    state['exp_avg'] = torch.zeros_like(p.data, memory_format=torch.preserve_format)
                    state['last_grad']= torch.zeros_like(p.data, memory_format=torch.preserve_format)
  
                exp_avg = state['exp_avg']
                grad_norm = torch.norm(grad, float('inf'))
                beta1 = grad_norm / (1 + grad_norm * grad_norm)

                state['step'] += 1
                bias_correction1 = 1 - beta1 ** state['step']

                if group['weight_decay'] != 0:
                    grad.add_(group['weight_decay'], p.data)

                exp_avg.mul_(beta1).add_(1 - beta1, grad)
                u = (1 - beta1)*grad + exp_avg + (1 - beta1) * (grad - beta1*state['last_grad'])
                step_size = group['lr'] / bias_correction1

                p.data.add_(-step_size, u)
                state['last_grad'] = grad.clone().detach()

        return loss