from __future__ import print_function

import torch.optim as optim
import torch.backends.cudnn as cudnn
import torchvision
import torchvision.transforms as transforms

import os
import argparse
import random

from models import *
from optim import *

def setup_seed(seed):
    np.random.seed(seed)
    random.seed(seed)
    torch.manual_seed(seed)  # cpu
    torch.cuda.manual_seed_all(seed)  
    torch.backends.cudnn.deterministic = True  
    torch.backends.cudnn.benchmark = True  


def get_parser():
    parser = argparse.ArgumentParser(description='PyTorch Training')
    parser.add_argument('--data', default='cifar10', type=str, help='data', choices=['cifar10', 'cifar100','stl10'])
    parser.add_argument('--model', default='resnet', type=str, help='model')
    parser.add_argument('--optim', default='sgd', type=str, help='optimizer')
    parser.add_argument('--lr', default=0.001, type=float, help='learning rate')
    parser.add_argument('--final_lr', default=0.1, type=float,
                        help='final learning rate of AdaBound')
    parser.add_argument('--gamma', default=1e-3, type=float)
    parser.add_argument('--momentum', default=0.9, type=float, help='momentum term')
    parser.add_argument('--beta1', default=0.9, type=float, help='Adam coefficients beta_1')
    parser.add_argument('--beta2', default=0.999, type=float, help='Adam coefficients beta_2')
    parser.add_argument('--resume', '-r', action='store_true', help='resume from checkpoint')
    parser.add_argument('--weight_decay', default=5e-6, type=float,
                        help='weight decay for optimizers')

    parser.add_argument('--bs', default=128, type=int)
    parser.add_argument('--epochs', default=150, type=int, help='number of epochs to train')
    parser.add_argument('--I', default=3.0, type=float)
    parser.add_argument('--D', default=10.0, type=float)
    args = parser.parse_args()
    if args.data == 'cifar10':
        setattr(args, 'num_classes', 10)
    elif args.data == 'cifar100':
        setattr(args, 'num_classes', 100)
    elif args.data == 'stl10':
        setattr(args, 'num_classes', 10)
    return args


def build_dataset(args):
    print('==> Preparing data..')
    transform_train = transforms.Compose([
        transforms.RandomCrop(32, padding=4),
        transforms.RandomHorizontalFlip(),
        transforms.ToTensor(),
        transforms.Normalize((0.4914, 0.4822, 0.4465), (0.2023, 0.1994, 0.2010)),
    ])

    transform_test = transforms.Compose([
        transforms.ToTensor(),
        transforms.Normalize((0.4914, 0.4822, 0.4465), (0.2023, 0.1994, 0.2010)),
    ])
    transform_train_stl10 = transforms.Compose([
        transforms.RandomCrop(96, padding=4),
        transforms.RandomHorizontalFlip(),
        transforms.ToTensor(),
        transforms.Normalize((0.5, 0.5, 0.5), (0.5, 0.5, 0.5)),
    ])

    transform_test_stl10 = transforms.Compose([
        transforms.ToTensor(),
        transforms.Normalize((0.5, 0.5, 0.5), (0.5, 0.5, 0.5)),
    ])
    if args.data == 'cifar10':
        trainset = torchvision.datasets.CIFAR10(root='/data/cifar10', train=True, download=True,
                                                transform=transform_train)
        testset = torchvision.datasets.CIFAR10(root='/data/cifar10', train=False, download=True,
                                               transform=transform_test)
    if args.data == 'cifar100':
        trainset = torchvision.datasets.CIFAR100(root='/data/cifar100', train=True, download=True,
                                                 transform=transform_train)
        testset = torchvision.datasets.CIFAR100(root='/data/cifar100', train=False, download=True,
                                                transform=transform_test)
    if args.data == 'stl10':
        trainset = torchvision.datasets.STL10('/data/stl10', split='train', transform=transform_train_stl10,
                                                           target_transform=None, download=True)
        testset = torchvision.datasets.STL10('/data/stl10', split='test', transform=transform_test_stl10,
                                                           target_transform=None, download=True)
    train_loader = torch.utils.data.DataLoader(trainset, batch_size=args.bs, shuffle=True,
                                               num_workers=2)
    test_loader = torch.utils.data.DataLoader(testset, batch_size=args.bs, shuffle=False, num_workers=2)

    return train_loader, test_loader


def get_ckpt_name(model='resnet', optimizer='sgd', lr=0.001, final_lr=0.1, momentum=0.9,
                  beta1=0.9, beta2=0.999, gamma=1e-3, I=3.0, D=10.00):
    name = {
        'sgd': 'lr{}-momentum{}'.format(lr, momentum),
        'adam': 'lr{}-betas{}-{}'.format(lr, beta1, beta2),
        'adabound': 'lr{}-betas{}-{}-final_lr{}-gamma{}'.format(lr, beta1, beta2, final_lr, gamma),
        'adapid': 'lr{}'.format(lr),
        'apollo': 'lr{}'.format(lr),
        'padam': 'lr{}-betas{}-{}'.format(lr, beta1, beta2),
        'pid': 'lr{}-momentum{}-I{}-D{}' .format(lr, momentum, I, D),
        'radam': 'lr{}-betas{}-{}'.format(lr, beta1, beta2),
        'adamw': 'lr{}-betas{}-{}'.format(lr, beta1, beta2),
        'adabelief': 'lr{}-betas{}-{}'.format(lr, beta1, beta2),
    }[optimizer]
    return '{}-{}-{}'.format(model, optimizer, name)


def load_checkpoint(ckpt_name):
    print('==> Resuming from checkpoint..')
    path = os.path.join('checkpoint', ckpt_name)
    assert os.path.isdir('checkpoint'), 'Error: no checkpoint directory found!'
    assert os.path.exists(path), 'Error: checkpoint {} not found'.format(ckpt_name)
    return torch.load(ckpt_name)


def build_model(args, device, ckpt=None):
    print('==> Building model..')
    net = {
        'resnet': ResNet34,
        'densenet': DenseNet121,
        'wideresnet': WideResNet_28x2
    }[args.model](args)
    net = net.to(device)
    if device == 'cuda':
        net = torch.nn.DataParallel(net)
        cudnn.benchmark = True

    if ckpt:
        net.load_state_dict(ckpt['net'])

    return net


def create_optimizer(args, model_params):
    if args.optim == 'sgd':
        return optim.SGD(model_params, args.lr, momentum=args.momentum,
                         weight_decay=args.weight_decay)
    elif args.optim == 'adam':
        return optim.Adam(model_params, args.lr, betas=(args.beta1, args.beta2),
                          weight_decay=args.weight_decay)
    elif args.optim == 'adabelief':
        return AdaBelief(model_params, args.lr, betas=(args.beta1, args.beta2),
                         weight_decay=args.weight_decay)
    elif args.optim == 'adabound':
        return AdaBound(model_params, args.lr, betas=(args.beta1, args.beta2),
                         final_lr=args.final_lr, gamma=args.gamma,
                         weight_decay=args.weight_decay, amsbound=False)
    elif args.optim == 'adapid':
        return AdaPID(model_params, args.lr,
                        weight_decay=args.weight_decay)
    elif args.optim == 'apollo':
        return Apollo(model_params, args.lr,
                        beta=0.9, eps=1e-8, rebound='constant', warmup=500, init_lr=None, weight_decay=args.weight_decay, weight_decay_type=None)
    elif args.optim == 'padam':
        return Padam(model_params, args.lr, betas=(args.beta1, args.beta2), eps=1e-8, weight_decay=args.weight_decay, amsgrad=True, partial = 1/4)
    elif args.optim == 'pid':
        return PID(model_params, args.lr, weight_decay=args.weight_decay, momentum=args.momentum,
                     I=args.I, D=args.D)
    elif args.optim == 'adamw':
        return AdamW(model_params, args.lr, betas=(args.beta1, args.beta2), weight_decay=args.weight_decay)
    elif args.optim == 'radam':
        return RAdam(model_params, args.lr, betas=(args.beta1, args.beta2), weight_decay=args.weight_decay)

def train(net, epoch, device, data_loader, optimizer, criterion):
    print('\nEpoch: %d' % epoch)
    net.train()
    train_loss = 0
    correct = 0
    total = 0
    neg_loss = 0
    for batch_idx, (inputs, targets) in enumerate(data_loader):
        inputs, targets = inputs.to(device), targets.to(device)
        if inputs.size(-1) == 28:
            inputs = inputs.view(inputs.size(0), -1)
        optimizer.zero_grad()
        outputs = net(inputs)
        loss = criterion(outputs, targets)
        loss.backward()
        optimizer.step()

        train_loss += loss.item()
        _, predicted = outputs.max(1)
        total += targets.size(0)
        correct += predicted.eq(targets).sum().item()
    accuracy = 100. * correct / total
    print('train acc %.3f' % accuracy)

    return train_loss, accuracy


def test(net, device, data_loader, criterion):
    net.eval()
    test_loss = 0
    correct = 0
    total = 0
    with torch.no_grad():
        for batch_idx, (inputs, targets) in enumerate(data_loader):
            inputs, targets = inputs.to(device), targets.to(device)
            if inputs.size(-1) == 28:
                inputs = inputs.view(inputs.size(0), -1)
            outputs = net(inputs)

            _, predicted = outputs.max(1)
            total += targets.size(0)
            correct += predicted.eq(targets).sum().item()

            loss = criterion(outputs, targets)
            test_loss += loss.item()

    accuracy = 100. * correct / total
    print(' test acc %.3f' % accuracy)
    return test_loss, accuracy


def main():
    # setup_seed(1)
    args = get_parser()

    train_loader, test_loader = build_dataset(args)
    device = 'cuda' if torch.cuda.is_available() else 'cpu'

    ckpt_name = get_ckpt_name(model=args.model, optimizer=args.optim, lr=args.lr,
                              final_lr=args.final_lr, momentum=args.momentum,
                              beta1=args.beta1, beta2=args.beta2,  gamma=args.gamma)

    if args.resume:
        ckpt = load_checkpoint(ckpt_name)
        best_acc = ckpt['acc']
        start_epoch = ckpt['epoch']
    else:
        ckpt = None
        best_acc = 0
        start_epoch = -1

    net = build_model(args, device, ckpt=ckpt)
    criterion = nn.CrossEntropyLoss()
    optimizer = create_optimizer(args, net.parameters())
    scheduler = optim.lr_scheduler.MultiStepLR(optimizer, milestones=[50, 100], gamma=0.1)

    train_losses = []
    train_accuracies = []
    test_losses = []
    test_accuracies = []
    for epoch in range(start_epoch + 1, args.epochs):

        train_loss, train_acc = train(net, epoch, device, train_loader, optimizer, criterion)

        test_loss, test_acc = test(net, device, test_loader, criterion)
        scheduler.step()

        # Save checkpoint.
        if test_acc > best_acc:
            print('Saving..')
            state = {
                'net': net.state_dict(),
                'acc': test_acc,
                'epoch': epoch,
            }
            if not os.path.isdir('checkpoint'):
                os.mkdir('checkpoint')
            torch.save(state, os.path.join('checkpoint', ckpt_name))
            best_acc = test_acc

        train_losses.append(train_loss)
        train_accuracies.append(train_acc)
        test_losses.append(test_loss)
        test_accuracies.append(test_acc)

        if not os.path.isdir('curve'):
            os.mkdir('curve')
        torch.save({'train_loss': train_losses, 'train_accuracy': train_accuracies,
                    'test_loss': test_losses, 'test_accuracy': test_accuracies},
                   os.path.join('curve', ckpt_name))

if __name__ == '__main__':
    main()
