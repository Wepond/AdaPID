import os
import matplotlib.pyplot as plt
import torch
import numpy as np
import math

LABELS = ['AdaPID','SGD','PID','Adam','AdaBound','AdamW','Padam','Apollo','AdaBelief','RAdam']
params = {'axes.labelsize': 16,
          'axes.titlesize': 16,
         }

plt.rcParams.update(params)

def get_data(names):
    folder_path = '\curve_myself'
    paths = [os.path.join(folder_path, name) for name in names]
    return {name: torch.load(fp) for name, fp in zip(names, paths)}

def plot(names, curve_type='train', labels = None, ylim=(30,110)):
    plt.figure()
    plt.ylim(ylim)# if curve_type == 'train' else 96)
    curve_data = get_data(names)
    for i, label in zip(curve_data.keys(),labels):
        acc = np.array(curve_data[i]['{}_loss'.format(curve_type.lower())])
        
        if label == 'AdaPID':
            plt.plot(acc, '-' ,label = label)
        else:
            plt.plot(acc, '--',label=label)
    
    plt.grid()
    plt.legend(fontsize=14, loc='upper right')
    plt.title('{} set perplexity ~ training epoch'.format(curve_type))
    plt.xlabel('Training Epoch')
    plt.ylabel('Perplexity')

if __name__=="__main__":
    #####################################################################################################LSTM_1layer

    names = ['PTB.pt-optimizer-adapid-nlayers3',
          'PTB.pt-optimizer-sgd-nlayers3',
          'PTB.pt-optimizer-pid-nlayers3',          
          'PTB.pt-optimizer-adam-nlayers3',
          'PTB.pt-optimizer-adabound-nlayers3',
          'PTB.pt-optimizer-adamw-nlayers3',
          'PTB.pt-optimizer-padam-nlayers3',
          'PTB.pt-optimizer-apollo-nlayers3',
          'PTB.pt-optimizer-adavelief-nlayers3',
          'PTB.pt-optimizer-radam-nlayers3',       
        ]
    labels = ['AdaPID','SGD','PID','Adam','AdaBound','AdamW','Padam','Apollo','AdaBelief','RAdam']
    
    plot(names, 'Train', labels = labels)
    plt.savefig('Train_lstm_3layer.png', dpi=600)
    plot(names, 'Test', ylim=(0,200), labels = labels)
    plt.savefig('Test_lstm_3layer.png', dpi=600)